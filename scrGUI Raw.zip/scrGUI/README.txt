==================================================
                 scrGUI Feature Guide
==================================================

PROFILES
--------------------------------------------------
Low            : 640p / 2 Mbps, lightweight
Medium         : 1080p / 4 Mbps, balanced
High           : 1920p / 8 Mbps, crisp visuals
Performance    : 1920p / 16 Mbps, screen off, max throughput
(best for laptop screen based gaming)
Advanced       : Custom resolution, bitrate, crop, saved persistently

TOGGLES
--------------------------------------------------
Fullscreen     : Fill monitor for immersive viewing
Always-on-top  : Window stays above others
Show touches   : Display tap indicators on screen

OPTIONS
--------------------------------------------------
Keyboard       : OTG passthrough typing
No Display     : Input only, no video
Turn Screen Off: Save battery & GPU performance while mirroring
Record         : Timestamped video, optional custom folder

ADVANCED
--------------------------------------------------
Custom res/bit : Fine-tune quality and performance
Record folder  : Choose save location
Crop           : Focus on region (w:h:x:y)
Example:
--crop 720:1280:0:0
This captures a 720x1280 region starting at the top-left corner of the device screen.

COMBOS
--------------------------------------------------
Performance + Record     : High-quality gameplay capture
No Display + Keyboard    : Passthrough typing
Fullscreen + Always-on-top: Best for referencing or calling
Crop + Record            : Focused app capture
Touches + Record         : Tutorial/demo videos

==================================================
scrGUI is a powerhouse. Use it wisely, or not ;)
==================================================