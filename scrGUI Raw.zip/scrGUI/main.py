import os, json, subprocess
from datetime import datetime
import customtkinter as ctk
from tkinter import filedialog

SCRCPY_PATH = os.path.join(os.path.dirname(__file__), "scrcpy", "scrcpy.exe")
CONFIG_FILE = os.path.join(os.path.dirname(__file__), "config.json")
README_FILE = os.path.join(os.path.dirname(__file__), "README.txt")

CFG = {
    "resolution": "", "bitrate": "", "crop": "",
    "feature_fullscreen": False, "feature_always_on_top": False, "feature_show_touches": False,
    "record_folder": ""
}

def load_config():
    if os.path.exists(CONFIG_FILE):
        try: CFG.update(json.load(open(CONFIG_FILE)))
        except: pass
load_config()

def save_config(): json.dump(CFG, open(CONFIG_FILE, "w"), indent=2)

def update_command(cmd):
    viewer.configure(state="normal")
    viewer.delete("0.0", "end")
    viewer.insert("0.0", " ".join(cmd))
    viewer.configure(state="disabled")

def show_toast(message):
    toast = ctk.CTkLabel(app, text=message, fg_color="#333", text_color="white", corner_radius=6)
    toast.place(relx=0.5, rely=0.95, anchor="s")
    app.after(2000, toast.destroy)

def run_scrcpy(profile, res, br, no_disp_flag, turn_off, kb):
    cmd = [SCRCPY_PATH]
    if res: cmd += ["--max-size", res]
    if br: cmd += ["--video-bit-rate", br]
    if CFG["crop"]: cmd += ["--crop", CFG["crop"]]
    if no_disp_flag: cmd.append("--no-playback")
    if turn_off: cmd.append("--turn-screen-off")
    if kb == "uhid": cmd += ["--keyboard=uhid"]
    if profile == "Performance Mode": cmd.append("--stay-awake")
    if fullscreen.get(): cmd.append("--fullscreen")
    if atop.get(): cmd.append("--always-on-top")
    if touches.get(): cmd.append("--show-touches")
    if record.get():
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        fn = f"scrGUI_Record_{ts}.mp4"
        folder = CFG["record_folder"]
        cmd += ["--record", os.path.join(folder, fn) if folder else fn]
    update_command(cmd)
    subprocess.Popen(cmd)
    show_toast("scrcpy launched.")

def launch():
    p = profile.get()
    res = br = ""
    off = turnoff.get()
    kb = "uhid" if keyboard.get() else "disabled"
    nd_flag = no_disp.get()

    if p == "Low Settings": res, br = "640", "2M"
    elif p == "Medium Settings": res, br = "1080", "4M"
    elif p == "High Settings": res, br = "1920", "8M"
    elif p == "Performance Mode": res, br = "1920", "16M"; off = True; nd_flag = False
    elif p == "Advanced Settings":
        res = adv_res.get().strip()
        br = adv_br.get().strip()
        CFG.update({"resolution": res, "bitrate": br})
        save_config()

    run_scrcpy(p, res, br, nd_flag, off, kb)

def open_adv():
    profile.set("Advanced Settings")
    win = ctk.CTkToplevel(app)
    win.title("Advanced")
    win.geometry("320x200")
    global adv_res, adv_br
    adv_res = ctk.StringVar(value=CFG["resolution"])
    adv_br = ctk.StringVar(value=CFG["bitrate"])
    ctk.CTkLabel(win, text="Resolution").pack(pady=2)
    ctk.CTkEntry(win, textvariable=adv_res).pack(pady=2)
    ctk.CTkLabel(win, text="Bitrate").pack(pady=2)
    ctk.CTkEntry(win, textvariable=adv_br).pack(pady=2)
    ctk.CTkLabel(win, text="Crop (optional)").pack(pady=2)
    crop_var = ctk.StringVar(value=CFG["crop"])
    ctk.CTkEntry(win, textvariable=crop_var).pack(pady=2)

    def save():
        CFG.update({
            "resolution": adv_res.get(),
            "bitrate": adv_br.get(),
            "crop": crop_var.get()
        })
        save_config()
        show_toast("Settings saved.")
        win.destroy()

    ctk.CTkButton(win, text="Save", command=save).pack(pady=4)

def choose_folder():
    f = filedialog.askdirectory()
    if f:
        CFG["record_folder"] = f
        save_config()
        folder_lbl.configure(text=f)

def open_feature_info():
    info = ctk.CTkToplevel(app)
    info.title("Feature Info")
    info.geometry("500x500")

    if os.path.exists(README_FILE):
        with open(README_FILE, "r", encoding="utf-8") as f:
            content = f.read()
    else:
        content = "README.txt not found in the scrGUI folder."

    box = ctk.CTkTextbox(info, width=480, height=460)
    box.pack(pady=6)
    box.insert("0.0", content)
    box.configure(state="disabled")

# -------------------------------
# UI setup
# -------------------------------
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

app = ctk.CTk()
app.title("scrGUI")
app.geometry("560x600")

profile = ctk.StringVar(value="Low Settings")
ctk.CTkLabel(app, text="Quality Profile").pack(pady=2)
ctk.CTkOptionMenu(app, variable=profile,
    values=["Low Settings", "Medium Settings", "High Settings", "Performance Mode", "Advanced Settings"]).pack(pady=2)
ctk.CTkButton(app, text="Open Advanced Settings", command=open_adv).pack(pady=2)

frame = ctk.CTkFrame(app)
frame.pack(pady=2)
fullscreen = ctk.BooleanVar(value=CFG["feature_fullscreen"])
atop = ctk.BooleanVar(value=CFG["feature_always_on_top"])
touches = ctk.BooleanVar(value=CFG["feature_show_touches"])
ctk.CTkCheckBox(frame, text="Fullscreen", variable=fullscreen).grid(row=0, column=0, padx=4, pady=2)
ctk.CTkCheckBox(frame, text="Always-on-top", variable=atop).grid(row=0, column=1, padx=4, pady=2)
ctk.CTkCheckBox(frame, text="Show touches", variable=touches).grid(row=0, column=2, padx=4, pady=2)

frame2 = ctk.CTkFrame(app)
frame2.pack(pady=2)
keyboard = ctk.BooleanVar(value=True)
no_disp = ctk.BooleanVar()
turnoff = ctk.BooleanVar()
record = ctk.BooleanVar()
ctk.CTkCheckBox(frame2, text="Keyboard", variable=keyboard).grid(row=0, column=0, padx=4, pady=2)
ctk.CTkCheckBox(frame2, text="No Display", variable=no_disp).grid(row=0, column=1, padx=4, pady=2)
ctk.CTkCheckBox(frame2, text="Turn Screen Off", variable=turnoff).grid(row=0, column=2, padx=4, pady=2)
ctk.CTkCheckBox(frame2, text="Record", variable=record).grid(row=0, column=3, padx=4, pady=2)

folder_lbl = ctk.CTkLabel(app, text=CFG["record_folder"] or "(default folder)")
folder_lbl.pack(pady=2)
ctk.CTkButton(app, text="Choose record folder", command=choose_folder).pack(pady=2)

ctk.CTkButton(app, text="Launch scrcpy", command=launch).pack(pady=6)
viewer = ctk.CTkTextbox(app, height=80, width=500)
viewer.pack(pady=2)
ctk.CTkButton(app, text="Copy command", command=lambda: app.clipboard_append(viewer.get("0.0", "end"))).pack(pady=2)

ctk.CTkButton(app, text="Feature Info", command=open_feature_info).pack(pady=6)

app.mainloop()